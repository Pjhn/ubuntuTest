double Minusfunc(double a, double b){
	return a-b;
}
