#include "calculator.h"

float Minusfunc(float a, float b){
	return a-b;
}
