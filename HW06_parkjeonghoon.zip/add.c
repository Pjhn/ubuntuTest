#include "calculator.h"

float Addfunc(float a, float b){
	return a+b;
} 
