#include "calculator.h"

float Dividefunc(float a, float b){
	return a/b;
}
