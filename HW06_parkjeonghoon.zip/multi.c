#include "calculator.h"

float Multifunc(float a, float b){
	return a*b;
}
