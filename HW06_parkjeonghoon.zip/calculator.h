#ifndef CALCULATOR_H
#define CALCULATOR_H

float Addfunc(float a, float b);
float Minusfunc(float a, float b);
float Multifunc(float a, float b);
float Dividefunc(float a, float b);

#endif
