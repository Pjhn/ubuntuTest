double Addfunc(double a, double b);
double Minusfunc(double a, double b);
double Multifunc(double a, double b);
double Dividefunc(double a, double b);
